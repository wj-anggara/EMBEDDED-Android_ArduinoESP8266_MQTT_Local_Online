/**
 * Created by anggara on 13/02/2018.
 * wj.anggara@gmail.com
 * https://github.com/wj-anggara
 * https://www.facebook.com/wj.anggara
 */
 

#include <ESP8266WiFi.h>
#include <PubSubClient.h>
#include "DHT.h"
#include <Servo.h> 
 
Servo myservo;
 
#define DHTTYPE DHT11
#define DHTPIN D4
DHT dht(DHTPIN, DHTTYPE);

float h;
float t;

const char* ssid = "WORKSHOP"; //SSID
const char* password = "jayalab#123ok"; //Password
const char* mqtt_server = "192.168.1.14"; //Broker lokal bisa diganti broker online


WiFiClient espClient;
PubSubClient client(espClient);
long lastMsg = 0;
char msg[50];
int value = 0;
String perintah="";

int relay = D6;
int pinServo = D5;
