package anggara.wj.smarthomeok;

import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by anggara on 13/02/2018.
 * wj.anggara@gmail.com
 * https://github.com/wj-anggara
 * https://www.facebook.com/wj.anggara
 */

public class Constants {
    //public static final String MQTT_BROKER_URL = "tcp://iot.eclipse.org:1883";
    public static final String MQTT_BROKER_URL = "tcp://192.168.1.14:1883";
    public static String PUBLISH_TOPIC = "";
    public static final String CLIENT_ID = "iot2018training";

    public static TextView shText, hmText;
    public static EditText subText, pubText;
}
