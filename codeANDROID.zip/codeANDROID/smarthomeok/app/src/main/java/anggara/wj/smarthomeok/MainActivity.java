package anggara.wj.smarthomeok;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import java.io.UnsupportedEncodingException;

/**
 * Created by anggara on 13/02/2018.
 * wj.anggara@gmail.com
 * https://github.com/wj-anggara
 * https://www.facebook.com/wj.anggara
 */

public class MainActivity extends AppCompatActivity {
    private MqttAndroidClient client;
    private String TAG = "MainActivity";
    private PahoMqttClient pahoMqttClient;


    private Button subButton, pubButton, relON, relOFF, keyOPEN, keyCLOSE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pahoMqttClient = new PahoMqttClient();

        //Init Text
        Constants.shText = (TextView) findViewById(R.id.shText);
        Constants.hmText = (TextView) findViewById(R.id.hmText);
        Constants.subText = (EditText) findViewById(R.id.subText);
        Constants.pubText = (EditText) findViewById(R.id.pubText);

        //Init Button
        subButton = (Button) findViewById(R.id.subButton);
        pubButton = (Button) findViewById(R.id.pubButton);
        relON = (Button) findViewById(R.id.relON);
        relOFF = (Button) findViewById(R.id.relOFF);
        keyOPEN = (Button) findViewById(R.id.keyOPEN);
        keyCLOSE = (Button) findViewById(R.id.keyCLOSE);

        //Mulai
        client = pahoMqttClient.getMqttClient(getApplicationContext(), Constants.MQTT_BROKER_URL, Constants.CLIENT_ID);

        //Subscribe Topic Update
        subButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String topic = Constants.subText.getText().toString().trim();
                if (!topic.isEmpty()) {
                    try {
                        pahoMqttClient.subscribe(client, topic, 1);
                    } catch (MqttException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        //Publish Topic Update
        pubButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.PUBLISH_TOPIC = Constants.pubText.getText().toString().trim();
            }
        });

        //Publish Relay ON
        relON.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try
                {
                    pahoMqttClient.publishMessage(client, "nyala", 1, Constants.PUBLISH_TOPIC);
                }
                catch (MqttException e)
                {
                    e.printStackTrace();
                }
                catch (UnsupportedEncodingException e)
                {
                    e.printStackTrace();
                }
            }
        });

        //Publish Relay OFF
        relOFF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    try {
                        pahoMqttClient.publishMessage(client, "mati", 1, Constants.PUBLISH_TOPIC);
                    } catch (MqttException e) {
                        e.printStackTrace();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
            }
        });

        //Publish Servo ON (OPEN The Door)
        keyOPEN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    try {
                        pahoMqttClient.publishMessage(client, "buka", 1, Constants.PUBLISH_TOPIC);
                    } catch (MqttException e) {
                        e.printStackTrace();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
            }
        });

        //Publish Servo OFF (CLOSE The Door)
        keyCLOSE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    try {
                        pahoMqttClient.publishMessage(client, "tutup", 1, Constants.PUBLISH_TOPIC);
                    } catch (MqttException e) {
                        e.printStackTrace();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
            }
        });

        Intent intent = new Intent(MainActivity.this, MqttMessageService.class);
        startService(intent);
    }
}
